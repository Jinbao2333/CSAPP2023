#include<stdio.h>
#include"util.h"

void bar() {
    printf("Execute bar function\n");
}