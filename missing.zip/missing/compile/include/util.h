void foo();
void bar();